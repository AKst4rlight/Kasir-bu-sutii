# Kasir Bu Suti — Android Offline

Aplikasi kasir Android native sederhana menggunakan Kotlin dan SQLite lokal.

## Fitur
- Dashboard omzet, keuntungan kotor, dan jumlah transaksi hari ini
- Data barang: tambah/edit nama, harga modal, harga jual, dan stok
- Kasir: keranjang, total otomatis, uang diterima, dan kembalian
- Checkout menyimpan transaksi dan mengurangi stok otomatis
- Riwayat transaksi dan laporan harian
- Cetak struk ke printer thermal Bluetooth ESC/POS yang sudah dipasangkan (paired) dengan HP
- Backup data produk dan transaksi ke file JSON
- Pulihkan data dari file JSON (mengganti data lokal saat ini)
- Tidak memerlukan koneksi internet untuk operasional setelah aplikasi terpasang

## Cetak struk Bluetooth
1. Nyalakan printer thermal Bluetooth.
2. Pasangkan printer melalui pengaturan Bluetooth Android terlebih dahulu.
3. Selesaikan transaksi lalu pilih **Cetak struk**, atau gunakan tombol tes cetak di Beranda.
4. Pilih nama printer yang sudah dipasangkan.
Catatan: fitur ditujukan untuk printer thermal Bluetooth serial (SPP) yang mendukung ESC/POS. Model printer BLE-only mungkin tidak kompatibel.

## Backup dan pemulihan
- Beranda > Backup data ke file untuk menyimpan file `backup_kasir_bu_suti.json`.
- Simpan salinan file tersebut di tempat aman (misalnya penyimpanan eksternal/komputer).
- Untuk pemulihan, pilih Pulihkan data dari backup dan pilih file JSON yang benar.
- Pemulihan mengganti seluruh produk dan transaksi yang tersimpan di aplikasi.

## Membuat APK
Proyek ini adalah source project Android Studio, bukan APK yang sudah dikompilasi.
1. Ekstrak ZIP.
2. Buka folder `Kasir_Bu_Suti_Android` melalui Android Studio.
3. Tunggu Gradle Sync selesai (penyiapan build pertama memerlukan Android SDK dan koneksi internet).
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Data transaksi dan stok tersimpan di database lokal aplikasi. Backup secara berkala disarankan.
