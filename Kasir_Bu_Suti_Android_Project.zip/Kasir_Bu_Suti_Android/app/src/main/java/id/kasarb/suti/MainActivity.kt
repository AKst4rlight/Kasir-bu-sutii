package id.kasarb.suti

import android.app.*
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.util.UUID
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

data class Product(val id:Int,val name:String,val buy:Long,val sell:Long,val stock:Int)
data class CartLine(val product:Product,var qty:Int)

class DB(ctx: android.content.Context): SQLiteOpenHelper(ctx,"kasir_bu_suti.db",null,1) {
    override fun onCreate(db:SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,buy INTEGER,sell INTEGER,stock INTEGER)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,total INTEGER,profit INTEGER,items TEXT)")
    }
    override fun onUpgrade(db:SQLiteDatabase,o:Int,n:Int) {}
    fun products():List<Product> {
        val a= mutableListOf<Product>(); readableDatabase.rawQuery("SELECT * FROM products ORDER BY name",null).use { c ->
            while(c.moveToNext()) a.add(Product(c.getInt(0),c.getString(1),c.getLong(2),c.getLong(3),c.getInt(4)))
        }; return a
    }
    fun save(p:Product) {
        val v=android.content.ContentValues().apply { put("name",p.name);put("buy",p.buy);put("sell",p.sell);put("stock",p.stock) }
        if(p.id==0) writableDatabase.insert("products",null,v) else writableDatabase.update("products",v,"id=?", arrayOf(p.id.toString()))
    }
    fun checkout(lines:List<CartLine>) {
        val total=lines.sumOf{it.product.sell*it.qty}; val profit=lines.sumOf{(it.product.sell-it.product.buy)*it.qty}
        val desc=lines.joinToString("; "){ "${it.product.name} x${it.qty}" }
        writableDatabase.beginTransaction()
        try {
            lines.forEach { writableDatabase.execSQL("UPDATE products SET stock=stock-? WHERE id=?", arrayOf(it.qty,it.product.id)) }
            val v=android.content.ContentValues().apply { put("date",SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date()));put("total",total);put("profit",profit);put("items",desc) }
            writableDatabase.insert("sales",null,v); writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun sales():List<String> {
        val a= mutableListOf<String>(); readableDatabase.rawQuery("SELECT date,total,profit,items FROM sales ORDER BY id DESC",null).use { c ->
            while(c.moveToNext()) a.add("${c.getString(0)}\n${c.getString(3)}\nOmzet ${rupiah(c.getLong(1))} • Untung ${rupiah(c.getLong(2))}")
        }; return a
    }
    fun backupJson():String {
        val root=JSONObject(); val productsArray=JSONArray(); val salesArray=JSONArray()
        readableDatabase.rawQuery("SELECT name,buy,sell,stock FROM products ORDER BY id",null).use { c ->
            while(c.moveToNext()) productsArray.put(JSONObject().put("name",c.getString(0)).put("buy",c.getLong(1)).put("sell",c.getLong(2)).put("stock",c.getInt(3)))
        }
        readableDatabase.rawQuery("SELECT date,total,profit,items FROM sales ORDER BY id",null).use { c ->
            while(c.moveToNext()) salesArray.put(JSONObject().put("date",c.getString(0)).put("total",c.getLong(1)).put("profit",c.getLong(2)).put("items",c.getString(3)))
        }
        root.put("app","Kasir Bu Suti").put("version",1).put("products",productsArray).put("sales",salesArray)
        return root.toString(2)
    }
    fun restoreJson(json:String) {
        val root=JSONObject(json); val products=root.getJSONArray("products"); val sales=root.getJSONArray("sales")
        writableDatabase.beginTransaction()
        try {
            writableDatabase.delete("products",null,null); writableDatabase.delete("sales",null,null)
            for(i in 0 until products.length()) {
                val o=products.getJSONObject(i); val v=android.content.ContentValues().apply {
                    put("name",o.getString("name"));put("buy",o.getLong("buy"));put("sell",o.getLong("sell"));put("stock",o.getInt("stock"))
                }; writableDatabase.insertOrThrow("products",null,v)
            }
            for(i in 0 until sales.length()) {
                val o=sales.getJSONObject(i); val v=android.content.ContentValues().apply {
                    put("date",o.getString("date"));put("total",o.getLong("total"));put("profit",o.getLong("profit"));put("items",o.getString("items"))
                }; writableDatabase.insert("sales",null,v)
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun summary():Triple<Long,Long,Int> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(profit),0),COUNT(*) FROM sales WHERE date LIKE ?", arrayOf(SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(Date())+"%")).use {
            it.moveToFirst(); return Triple(it.getLong(0),it.getLong(1),it.getInt(2))
        }
    }
}
fun rupiah(n:Long)=NumberFormat.getCurrencyInstance(Locale("in","ID")).format(n).replace(",00","")

class MainActivity:Activity() {
    lateinit var db:DB; lateinit var body:LinearLayout
    val cart= mutableListOf<CartLine>()
    var page="home"
    var pendingReceipt:String=""
    val btPermission= android.Manifest.permission.BLUETOOTH_CONNECT
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null) return
        try {
            val uri=data.data!!
            when(requestCode) {
                701 -> contentResolver.openOutputStream(uri)?.use { it.write(db.backupJson().toByteArray(Charsets.UTF_8)) ; msg("Backup berhasil disimpan") }
                702 -> contentResolver.openInputStream(uri)?.bufferedReader()?.use { db.restoreJson(it.readText());msg("Data berhasil dipulihkan");showHome() }
            }
        } catch(e:Exception) { msg("Gagal memproses file: ${e.message}") }
    }
    override fun onCreate(b:Bundle?) { super.onCreate(b); db=DB(this); showHome() }
    fun base(title:String) {
        val outer=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(18,18,18,12);setBackgroundColor(0xFFF5F7FB.toInt()) }
        val head=TextView(this).apply { text=title; textSize=23f; setTextColor(0xFF172554.toInt()); typeface=Typeface.DEFAULT_BOLD;setPadding(4,8,4,16) }
        outer.addView(head); body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val scroll=ScrollView(this);scroll.addView(body);outer.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val nav=LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        listOf("Beranda","Kasir","Stok","Transaksi","Laporan").forEach { s -> nav.addView(Button(this).apply { text=s; textSize=10f;setOnClickListener { when(s){"Beranda"->showHome();"Kasir"->showCashier();"Stok"->showStock();"Transaksi"->showSales();else->showReport()} } },LinearLayout.LayoutParams(0,-2,1f)) }
        outer.addView(nav);setContentView(outer)
    }
    fun label(s:String,size:Float=16f) { body.addView(TextView(this).apply{text=s;textSize=size;setTextColor(0xFF1F2937.toInt());setPadding(4,9,4,9)}) }
    fun btn(s:String,action:()->Unit) { body.addView(Button(this).apply{text=s;setOnClickListener{action()}}) }
    fun field(hint:String):EditText { val e=EditText(this);e.hint=hint;e.inputType=2;body.addView(e);return e }
    fun showHome() { base("Kasir Bu Suti");val x=db.summary()
        label("Ringkasan penjualan hari ini",14f);label("Omzet: ${rupiah(x.first)}",21f);label("Keuntungan: ${rupiah(x.second)}",19f);label("Jumlah transaksi: ${x.third}")
        label("Kelola toko sembako secara offline.");btn("Mulai transaksi"){showCashier()};btn("Tambah / kelola barang"){showStock()}
        btn("Cetak struk Bluetooth"){choosePrinter("TES CETAK\\nKasir Bu Suti\\nPrinter siap digunakan\\n\\n\\n")}
        btn("Backup data ke file"){backupData()};btn("Pulihkan data dari backup"){restoreData()}
    }
    fun showStock() { base("Stok Barang");btn("+ Tambah barang"){addProduct()}
        db.products().forEach { p -> label("${p.name}\nModal ${rupiah(p.buy)} • Jual ${rupiah(p.sell)} • Stok ${p.stock}")
            btn("Edit ${p.name}"){editProduct(p)} }
    }
    fun addProduct() { base("Tambah Barang");val n=EditText(this).apply{hint="Nama barang"};body.addView(n)
        val b=field("Harga modal");val s=field("Harga jual");val q=field("Jumlah stok")
        btn("Simpan barang"){try{if(n.text.isBlank()) throw Exception();db.save(Product(0,n.text.toString(),b.text.toString().toLong(),s.text.toString().toLong(),q.text.toString().toInt()));showStock()}catch(e:Exception){msg("Periksa nama, harga, dan stok")}}
    }
    fun editProduct(p:Product) { base("Edit Barang");val n=EditText(this).apply{setText(p.name)};body.addView(n)
        val b=field("Harga modal");b.setText(p.buy.toString());val s=field("Harga jual");s.setText(p.sell.toString());val q=field("Stok");q.setText(p.stock.toString())
        btn("Simpan perubahan"){try{db.save(Product(p.id,n.text.toString(),b.text.toString().toLong(),s.text.toString().toLong(),q.text.toString().toInt()));showStock()}catch(e:Exception){msg("Data belum valid")}}
    }
    fun showCashier() { base("Kasir / Penjualan");label("Pilih barang untuk dimasukkan ke keranjang",13f)
        db.products().filter{it.stock>0}.forEach { p -> btn("${p.name} • ${rupiah(p.sell)} • Stok ${p.stock}") {
            val line=cart.find{it.product.id==p.id};if(line==null)cart.add(CartLine(p,1)) else if(line.qty<p.stock)line.qty++;showCashier()
        } }
        label("KERANJANG",18f);cart.toList().forEach { l -> label("${l.product.name} x${l.qty} = ${rupiah(l.product.sell*l.qty)}");btn("Hapus ${l.product.name}"){cart.remove(l);showCashier()} }
        val total=cart.sumOf{it.product.sell*it.qty};label("TOTAL: ${rupiah(total)}",22f)
        btn("Proses pembayaran"){if(cart.isEmpty())msg("Keranjang masih kosong") else payment(total)}
    }
    fun payment(total:Long) { val e=EditText(this).apply{hint="Uang diterima";inputType=2};AlertDialog.Builder(this).setTitle("Pembayaran ${rupiah(total)}").setView(e)
        .setPositiveButton("Bayar"){_,_->try{val paid=e.text.toString().toLong();if(paid<total){msg("Uang pembayaran kurang");return@setPositiveButton};val change=paid-total;db.checkout(cart);cart.clear();AlertDialog.Builder(this).setMessage("Transaksi berhasil\nKembalian: ${rupiah(change)}").setPositiveButton("OK"){_,_->showHome()}.show()}catch(ex:Exception){msg("Masukkan nominal uang")}}
        .setNegativeButton("Batal",null).show()
    }
    fun showSales() { base("Riwayat Transaksi");val a=db.sales();if(a.isEmpty())label("Belum ada transaksi") else a.forEach{label(it)} }
    fun showReport() { base("Laporan & Keuntungan");val x=db.summary();label("LAPORAN HARI INI");label("Total omzet: ${rupiah(x.first)}",20f);label("Estimasi keuntungan kotor: ${rupiah(x.second)}",19f);label("Transaksi: ${x.third}");label("Keuntungan dihitung dari (harga jual - harga modal) x jumlah terjual.",13f) }
    fun receiptText(lines:List<CartLine>,total:Long,paid:Long,change:Long):String {
        val out=StringBuilder()
        out.append("          KASIR BU SUTI\\n")
        out.append("--------------------------------\\n")
        out.append(SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(Date())).append("\\n")
        lines.forEach { out.append(it.product.name).append(" x").append(it.qty).append("\\n")
            out.append("  ").append(rupiah(it.product.sell)).append(" = ").append(rupiah(it.product.sell*it.qty)).append("\\n") }
        out.append("--------------------------------\\n")
        out.append("TOTAL       ").append(rupiah(total)).append("\\n")
        out.append("DIBAYAR     ").append(rupiah(paid)).append("\\n")
        out.append("KEMBALIAN   ").append(rupiah(change)).append("\\n")
        out.append("\\n       Terima kasih\\n\\n\\n")
        return out.toString()
    }
    fun choosePrinter(text:String) {
        val adapter=BluetoothAdapter.getDefaultAdapter()
        if(adapter==null) { msg("HP tidak mendukung Bluetooth");return }
        if(android.os.Build.VERSION.SDK_INT>=31 && checkSelfPermission(btPermission)!=android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(btPermission),801);pendingReceipt=text;return
        }
        if(!adapter.isEnabled) { msg("Aktifkan Bluetooth terlebih dahulu");return }
        try {
            val devices=adapter.bondedDevices.toList()
            if(devices.isEmpty()) { msg("Pairing printer Bluetooth di pengaturan HP terlebih dahulu");return }
            val names=devices.map { "${it.name ?: "Printer"} (${it.address})" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Pilih printer yang sudah dipasangkan")
                .setItems(names) { _,which -> sendToPrinter(devices[which],text) }.setNegativeButton("Batal",null).show()
        } catch(e:SecurityException) { msg("Izin Bluetooth belum diberikan") }
    }
    fun sendToPrinter(device:BluetoothDevice,text:String) {
        Thread {
            var socket:BluetoothSocket?=null
            try {
                socket=device.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                socket.connect()
                val stream:OutputStream=socket.outputStream
                stream.write(byteArrayOf(0x1B,0x40))
                stream.write(text.toByteArray(Charsets.US_ASCII))
                stream.write(byteArrayOf(0x1D,0x56,0x00))
                stream.flush()
                runOnUiThread { msg("Struk berhasil dikirim ke printer") }
            } catch(e:Exception) { runOnUiThread { msg("Gagal mencetak. Periksa printer dan pairing Bluetooth") } }
            finally { try { socket?.close() } catch(_:Exception){} }
        }.start()
    }
    fun backupData() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="application/json";putExtra(Intent.EXTRA_TITLE,"backup_kasir_bu_suti.json") }
        startActivityForResult(i,701)
    }
    fun restoreData() {
        AlertDialog.Builder(this).setTitle("Pulihkan data")
            .setMessage("Data produk dan transaksi saat ini akan diganti dengan isi file backup. Lanjutkan hanya jika file backup benar.")
            .setPositiveButton("Pilih file"){_,_->
                val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE);type="application/json" }
                startActivityForResult(i,702)
            }.setNegativeButton("Batal",null).show()
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==801 && grantResults.isNotEmpty() && grantResults[0]==android.content.pm.PackageManager.PERMISSION_GRANTED) choosePrinter(pendingReceipt)
        else if(requestCode==801) msg("Izin Bluetooth diperlukan untuk mencetak")
    }
    fun msg(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
